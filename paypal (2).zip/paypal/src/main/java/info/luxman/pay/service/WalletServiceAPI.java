package info.luxman.pay.service;

import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Luxman_S on 4/12/2017.
 */
@RestController
public class WalletServiceAPI {

    public String
}


