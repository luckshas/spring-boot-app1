package info.luxman;

import info.luxman.service.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

/**
 * Created by luxmanseshadri on 4/11/17.
 */
@RestController
@RequestMapping("/service")
public class UserServiceAPI {

    Logger logger = Logger.getLogger(UserServiceAPI.class.toString());
    @Autowired
    private UserRepository userRepo;

    @RequestMapping(value = "/login1", method = RequestMethod.POST)
    public String login(User princ)
    {

        return "{\"authenticated\":true} ";
    }
    @RequestMapping( value="/users", method = RequestMethod.POST)
    public String createUser (@RequestBody User user)
    {
        logger.info("User to be created " + user.getUsername() );
        userRepo.save(user);
        return "{\"status\":\"OK\"}";
    }

    @RequestMapping(value="/users", method = RequestMethod.GET)
    public List<User> searchUsers(@RequestParam(name="username",required = false) String username)
    {
        logger.info(" Search users");
        return userRepo.findAll();
    }
}
