package info.luxman.model;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class CreditCardPaymentMethod extends PaymentMethodImpl {
    private String creditCardNumber;
    private String creditCardlast4;
    private String expirationDate;
    private Address address;
}
