package info.luxman.model;

import java.security.Timestamp;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class WalletTransactionHistory {

    private String txnStatus;
    private String txndescription;
    private String txnDebitCredit;
    private String txnType;
    private double txnGross;
    private double txnFee;
    private double net;
    private double balance;
    private Timestamp txnTimeStamp;


}
