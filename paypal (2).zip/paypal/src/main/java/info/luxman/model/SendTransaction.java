package info.luxman.model;

import java.util.Currency;

/**
 * Created by Luxman_S on 4/12/2017.
 */
@Entity
public class SendTransaction {
    private String email;
    private String mobileNumber;
    private Double amount;
    private Currency currency;

}
