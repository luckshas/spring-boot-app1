package info.luxman.model;

import java.util.List;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class PaymentMethods {

    private List<PaymentMethodImpl> paymentMethod;
}
