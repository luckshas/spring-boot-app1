package info.luxman.model;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public abstract class PaymentMethodImpl {
    protected
}
