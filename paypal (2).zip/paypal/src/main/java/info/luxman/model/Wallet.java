package info.luxman.model;

import java.security.Timestamp;
import java.util.Currency;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class Wallet {
    private double balance;
    private Currency currency;
    private Timestamp lastTransactionDate;
    private String status;
    private String country

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Timestamp getLastTransactionDate() {
        return lastTransactionDate;
    }

    public void setLastTransactionDate(Timestamp lastTransactionDate) {
        this.lastTransactionDate = lastTransactionDate;
    }
}
