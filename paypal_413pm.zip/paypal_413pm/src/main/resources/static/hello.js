var app = angular.module("login", ["ngRoute"]);

app.config(function ($routeProvider) {
    $routeProvider
    // login view definition
        .when("/login", {
            controller: "loginController",
            controllerAs: "vm",
            templateUrl: "login.html"
        })
        // main app view definition
        .when("/index", {
             controller: "mainController",
            controllerAs: "vm",
            templateUrl: "index.html"
        })
        // many other routes could be defined here
        // and redirect the user to the main view if no routes match
        .otherwise({
            redirectTo: "/login"
        });
});

// execute this function when the main module finishes loading
app.run(function ($rootScope, $location) {
    // attach to the event that fires before the router changes routes
    $rootScope.$on("$routeChangeStart", function (event, next) {
        // check current login status and filter out if navigating to login
        if (!$rootScope.loggedIn && next.originalPath !== "/login") {
            // remember the original url
            $location.url("/login?back=" + $location.url());
        }
    });
});

app.service("loginService", function ($http) {
    return {
        checkLogin: function () {
            console.log ("Checklogin");
            return $http.get("/creds.json").then(function (response) {
                return response.data;
            });
        },
        login: function (user, pass) {
            console.log("InsideLogin");
            return $http.post("/creds.json", {
                user: user,
                pass: pass
            }).then(function (response) {
                return response.data;
            }, function (response) {
                var err = new Error(response.statusText);
                err.code = response.status;
                throw err;
            });
        }
    };
});

app.controller("loginController", function ($rootScope, $location, loginService) {
    var vm = this;
             console.log(vm.user+vm.pass);

    function success() {
        $rootScope.loggedIn = true;

        var back = $location.search().back || "";
        $location.url(back !== "/login" ? back : "");
    }

    function failure() {
        $rootScope.loggedIn = false;
    }

    loginService.checkLogin().then(success);
    vm.login = function () {
        console.log("invoked login");
        loginService.login(vm.user, vm.pass).then(success, failure);
    };
});