package info.luxman.pay.service;

import info.luxman.pay.exception.BadRequestException;
import info.luxman.pay.model.Account;
import info.luxman.pay.model.HumanTransaction;
import info.luxman.pay.model.Wallet;
import info.luxman.pay.model.WalletTransactionHistory;
import info.luxman.pay.service.repository.AccountRepository;
import info.luxman.pay.service.repository.HumanTransactionRepository;
import info.luxman.pay.service.repository.TransactionHistoryRepository;
import info.luxman.pay.service.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.Currency;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
@Service
@Configuration
public class WalletService {

    Logger logger = Logger.getLogger(WalletService.class.toString());
    @Autowired
    private Environment environment;

    @Autowired
    MongoOperations mongoOperations;

    @Autowired
    private WalletRepository walletRepo;

    @Autowired
    private TransactionHistoryRepository transactionRepo;

    @Autowired
    private HumanTransactionRepository humanTxnRepo;

    @Autowired
    private AccountRepository accountRepo;

    /*
     * creates a wallet with the account parameters.
     * account is credited with $100 (kept configurable) as a opening bounus.
     */
    public Wallet createWallet(Account account)
    {
        Wallet wallet = new Wallet();
        wallet.setBalance(Integer.parseInt(environment.getProperty("wallet.credit")));
        wallet.setCurrency(Currency.getInstance("USD"));
        wallet.setUsername(account.getUsername());
       // wallet.setId(UUID.randomUUID().toString());
        Wallet createdWallet = walletRepo.save(wallet);
        logger.info("wallet  created "+ createdWallet.getId());
        addTransactionHistory(createdWallet,"Account created with credit "+createdWallet.getBalance());
        return createdWallet;
    }
    /*
    * add a transaction history to the account
     */
    public WalletTransactionHistory addTransactionHistory(Wallet wallet,String txnDescription)
    {
        WalletTransactionHistory th = new WalletTransactionHistory();
        th.setId(wallet.getId());
        th.setUsername(wallet.getUsername());
        th.setBalance(wallet.getBalance());
        //TODO change enum
        th.setTxnDebitCredit("credit");
        th.setTxndescription(txnDescription);
        th.setTxnFee(0.0);
        th.setTxnGross(0.0);
        th.setTxnTimeStamp(wallet.getTransactionDate());
        WalletTransactionHistory createdTh = transactionRepo.save(th);
    logger.info("Transaction history created "+ createdTh.getId());
        return createdTh;
    }
    public List<WalletTransactionHistory> getTransactionHistory(String id)
    {
        return transactionRepo.getActivityById(id);
    }
    /*public Wallet getWalletByUser(String username)
    {
        Wallet wallet = walletRepo.findByUsername(username);
        return wallet;

    }*/
    /*
     * service method returning a wallet  by filtering by email.
     * returns null if none is found
     */
    public Wallet getWalletByEmail(String email)
    {
        Query q = new Query();
        q.addCriteria(Criteria.where("username").is(email));
        List<Wallet> wallets = mongoOperations.find(q,Wallet.class);
        logger.info("wallet  "+wallets+"");
        if(wallets != null&& wallets.size()>0)
        {
            return wallets.get(0);
        }
        return null;
    }
    /*
    * service method returning a wallet history by filtering by email.
    * returns the list of transaction activity
     */
    public List<WalletTransactionHistory> getWalletHistoryByEmail(String email)
    {
        Query q = new Query();
        q.addCriteria(Criteria.where("username").is(email));
        List<WalletTransactionHistory> walletHistory = mongoOperations.find(q,WalletTransactionHistory.class);
        logger.info("wallet  "+walletHistory+"");
        if(walletHistory != null&& walletHistory.size()>0)
        {
            return walletHistory;
        }
        return null;
    }
    /*
    * service method for issuing a request to receive money from another account.
    * this method validates for the to account and records that a request has been sent in requester's and target's log.
     */
    public HumanTransaction requestMoney(HumanTransaction txn) throws BadRequestException {
        Wallet wallet = this.getWalletByEmail(txn.getUsername());
        //TODO validate for sending user
        Wallet recvwallet = this.walletRepo.findByUsername(txn.getEmail());
        if(recvwallet == null)
        {
            throw new BadRequestException("to email address does not exist.Please verify if the email address is accurate");

        }
        txn.setId(UUID.randomUUID().toString());
        HumanTransaction postedTxn = humanTxnRepo.save(txn);
        addTransactionHistory(wallet,"Request sent to " + txn.getEmail());
        addTransactionHistory(recvwallet,"Request sent by " + txn.getUsername());

        return postedTxn;
    }

    /*
    *  service method for sending money to an account.
    *  this method run validation on balance and to user, updates the wallet balance, records the transaction.
     */
    public HumanTransaction sendMoney(HumanTransaction txn) throws BadRequestException {
        Wallet wallet = this.getWalletByEmail(txn.getUsername());
        if(txn.getAmount()> wallet.getBalance())
        {
            throw new BadRequestException("wallet balance low. Please add the required amount to transfer");
        }
        // instead of account wallet is validated. irrespective of the account if wallet is not available money transfer fails.
        Wallet recvwallet = this.walletRepo.findByUsername(txn.getEmail());
        if(wallet == null)
        {
            throw new BadRequestException("no account exists with the to email address.Please verify if the email address is accurate");

        }
        txn.setId(UUID.randomUUID().toString());
        HumanTransaction postedTxn =humanTxnRepo.save(txn);
        wallet.setBalance(wallet.getBalance()-txn.getAmount());
        recvwallet.setBalance(wallet.getBalance()+txn.getAmount());
        walletRepo.save(wallet);
        walletRepo.save(recvwallet);
        addTransactionHistory(wallet,"Money sent to " + txn.getEmail());
        // ideally would have posted it to a queue or called an api for sending the money.
        addTransactionHistory(recvwallet,"Money received from " + txn.getUsername());

        return postedTxn;
    }
    public List<HumanTransaction> findHumanTransactionNotCompletedForAUser(String email)
    {
        Query q = new Query();
        q.addCriteria(Criteria.where("username").is(email).and("status").is("OPEN"));
        List<HumanTransaction> humanTxn = mongoOperations.find(q,HumanTransaction.class);
        logger.info("wallet  "+humanTxn+"");
        if(humanTxn != null&& humanTxn.size()>0)
        {
            return humanTxn;
        }
        return null;
    }
}
