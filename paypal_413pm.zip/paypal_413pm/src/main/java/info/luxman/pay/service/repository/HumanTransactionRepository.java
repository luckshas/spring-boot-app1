package info.luxman.pay.service.repository;

import info.luxman.pay.model.HumanTransaction;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
public interface HumanTransactionRepository extends MongoRepository<HumanTransaction,String> {
   // HumanTransaction findByOpenStatus(String username);
}
