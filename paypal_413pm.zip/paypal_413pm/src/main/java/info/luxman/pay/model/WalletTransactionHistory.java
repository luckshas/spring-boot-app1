package info.luxman.pay.model;


import javax.persistence.Id;
import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class WalletTransactionHistory {

    @Id
    private String id;
    private String username;
    private String txnStatus;
    private String txndescription;
    private String txnDebitCredit;
    private String txnType;
    private double txnGross;
    private double txnFee;
    private double net;
    private double balance;
    private Date txnTimeStamp;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getTxndescription() {
        return txndescription;
    }

    public void setTxndescription(String txndescription) {
        this.txndescription = txndescription;
    }

    public String getTxnDebitCredit() {
        return txnDebitCredit;
    }

    public void setTxnDebitCredit(String txnDebitCredit) {
        this.txnDebitCredit = txnDebitCredit;
    }

    public String getTxnType() {
        return txnType;
    }

    public void setTxnType(String txnType) {
        this.txnType = txnType;
    }

    public double getTxnGross() {
        return txnGross;
    }

    public void setTxnGross(double txnGross) {
        this.txnGross = txnGross;
    }

    public double getTxnFee() {
        return txnFee;
    }

    public void setTxnFee(double txnFee) {
        this.txnFee = txnFee;
    }

    public double getNet() {
        return net;
    }

    public void setNet(double net) {
        this.net = net;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Date getTxnTimeStamp() {
        return txnTimeStamp;
    }

    public void setTxnTimeStamp(Date txnTimeStamp) {
        this.txnTimeStamp = txnTimeStamp;
    }
}
