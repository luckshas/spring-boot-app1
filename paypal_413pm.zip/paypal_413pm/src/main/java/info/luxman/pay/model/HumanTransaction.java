package info.luxman.pay.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.util.Currency;
import java.util.Date;

/**
 * Created by Luxman_S on 4/12/2017.
 */
@Entity
public class HumanTransaction {
    @javax.persistence.Id
    private String Id;
    @NotNull
    private String email;
    private String mobileNumber;
    private Date transactionDate;
    private String status;
    @NotNull
    private Double amount;
    private Currency currency;
    //TODO enum reqeust send
    private String type;
    @NotNull
    private String username;

    public HumanTransaction()
    {
        transactionDate = new Date();
        setCurrency(Currency.getInstance("USD"));
        setStatus("OPEN");
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
