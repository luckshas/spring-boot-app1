package info.luxman.pay.service.repository;

import info.luxman.pay.model.Account;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Luxman_S on 4/12/2017.
 */
@Repository
public interface AccountRepository extends MongoRepository<Account,String> {


    Account findUserByUsername(String username);
}
