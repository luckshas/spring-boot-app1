package info.luxman.pay.service.repository;

import info.luxman.pay.model.Wallet;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
public interface WalletRepository  extends MongoRepository<Wallet,String> {
    Wallet findByUsername(String username);
}
