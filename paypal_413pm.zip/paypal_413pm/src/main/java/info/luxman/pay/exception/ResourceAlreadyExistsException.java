package info.luxman.pay.exception;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
public class ResourceAlreadyExistsException extends Exception {
    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(int httpCode) {
        this.httpCode = httpCode;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    private String message;
    private int httpCode;
    private String path;

    public ResourceAlreadyExistsException(String message)
    {
        this.message = message;
        httpCode = 409;
    }


}
