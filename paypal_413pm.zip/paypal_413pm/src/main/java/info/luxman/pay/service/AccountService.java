package info.luxman.pay.service;

import info.luxman.pay.exception.ResourceAlreadyExistsException;
import info.luxman.pay.model.Account;
import info.luxman.pay.service.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
@Service
public class AccountService {

    @Autowired
   private AccountRepository userRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    /*
     * creates an account with the supplied attributes.
     * password is hashed with bcrypt password encoder.
     */
    public Account createUser(Account account) throws ResourceAlreadyExistsException{
        account.setId(UUID.randomUUID().toString());
        //there are other options spring supports this seems best
        account.setPassword(bCryptPasswordEncoder.encode(account.getPassword()));
        Account existingUser = userRepository.findUserByUsername(account.getUsername());
        if(null == existingUser) {
            existingUser = userRepository.save(account);
        }
        else
        {
            throw new ResourceAlreadyExistsException("Account already exists"+existingUser.getUsername());
        }

       return existingUser;

    }
    /*
     *returns all the accounts.
     * TODO improve by filtering.
     */
    public List<Account> listAccounts()
    {
        return userRepository.findAll();
    }
}
