package info.luxman.pay.model;

import org.springframework.data.annotation.Id;

import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.Currency;
import java.util.Date;
import java.util.UUID;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class Wallet {
    @Id
    private String id;
    private double balance;
    private Currency currency;
    private Date transactionDate;
    private String status;
    private String country;
    @NotNull
    private String username;

    public Wallet()
    {
        transactionDate = new Date();
        setId(UUID.randomUUID().toString());
        setCurrency(Currency.getInstance("USD"));
        setStatus("ACTIVE");
        setCountry("USA");
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
