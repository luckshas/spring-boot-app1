package info.luxman.pay.exception;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
public class ApplicationException extends Exception {

    private String errorCode;
    private String errorDesciption;

    public ApplicationException()
    {
        super();
    }
    public ApplicationException(String errorCode, String errorDesciption)
    {
        this.errorCode = errorCode;
        this.errorDesciption = errorDesciption;
    }
}
