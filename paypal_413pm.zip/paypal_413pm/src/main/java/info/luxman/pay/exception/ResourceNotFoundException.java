package info.luxman.pay.exception;

/**
 * Created by luxmanseshadri on 4/13/17.
 */
public class ResourceNotFoundException extends Exception{

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(int httpCode) {
        this.httpCode = httpCode;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    private String message;
    private int httpCode;
    private String path;

    public ResourceNotFoundException(String message)
    {
        this.message = message;
        httpCode = 404;
    }
    public ResourceNotFoundException(String message,String path)
    {
        this.message = message;
        this.path= path;
        httpCode = 404;
    }

}
