package info.luxman.pay.pay.service;

import info.luxman.pay.exception.BadRequestException;
import info.luxman.pay.exception.ResourceNotFoundException;
import info.luxman.pay.model.HumanTransaction;
import info.luxman.pay.model.Wallet;
import info.luxman.pay.model.WalletTransactionHistory;
import info.luxman.pay.service.WalletService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.QueryParam;
import java.net.URI;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by Luxman_S on 4/12/2017.
 */
@RestController
@RequestMapping("/wallet")
@Api(basePath = "/users", value = "Account", description = "Operations with an account", produces = "application/json")
public class WalletServiceAPI {

    Logger logger = Logger.getLogger(WalletService.class.toString());
    @Autowired
    WalletService walletService;
/*
    @RequestMapping(value = "/balance/{username}", method = RequestMethod.GET)
    public ResponseEntity getWalletBalance(@PathVariable String username)
    {
        logger.info("fetching wallet balance for " +  username);
        Wallet wallet =  walletService.getWalletByEmail(username);
        logger.info("fetched " + ((wallet == null)? "none":wallet.getId()));
        return ResponseEntity.ok(wallet);

    }*/

    /*
     * retreives wallet balance for a user. if the wallet is not found a 404 is returned
     */
    @ApiOperation(notes = "gets wallet balance", value = "wallet balance", nickname = "walletbalance",
            tags = {"Wallet"} )
    @ApiResponses({
            @ApiResponse(code = 200, message ="wallet balance",response = Wallet.class),
            @ApiResponse(code = 404, message = "Resouce not found" )
    })
    @RequestMapping(value = "/balance/", method = RequestMethod.GET)
    public ResponseEntity getWalletBalance(@ApiParam(value = "username", required = true ) @QueryParam(value="username") String username , HttpServletRequest request) throws ResourceNotFoundException {
        logger.info("fetching wallet balance for " +  username);
        Wallet wallet =  walletService.getWalletByEmail (username);
        if( null == wallet) {
           throw new ResourceNotFoundException("requested wallet is not found " + username,URI.create(request.getRequestURI()).getPath());

        }
        logger.info("fetched " + ((wallet == null)? "none":wallet.getId()));
        return ResponseEntity.ok(wallet);

    }

    /*
    * retrieves the wallet history by username.if the wallet or history is not found a 404 is returned
     */
    @ApiOperation(notes = "activity history", value = "activity history", nickname = "activity",
            tags = {"Activity"} )
    @ApiResponses({
            @ApiResponse(code = 200, message = "Activity history",response = WalletTransactionHistory.class),
            @ApiResponse(code = 404, message = "Resouce not found" )
    })
    @RequestMapping(value = "/history/", method = RequestMethod.GET)
    public List<WalletTransactionHistory> getWalletHistory(@ApiParam(value = "username", required = true ) @QueryParam(value="username") String username,  HttpServletRequest request) throws ResourceNotFoundException, BadRequestException {
        //TODO validation for email
        if(null == username)
        {
            throw new BadRequestException("query parameter username is mandatory");
        }
        logger.info("fetching activity history for " +  username);
        List<WalletTransactionHistory> wthList =  walletService.getWalletHistoryByEmail(username);
        if( null == wthList) {
            throw new ResourceNotFoundException("requested wallet is not found " + username,URI.create(request.getRequestURI()).getPath());

        }
        logger.info("fetched " + ((wthList == null)? "none":wthList.size()));
        return wthList;

    }
    /*
     * requests money from another account. the account should already be  existing.
     */
    @ApiOperation(notes = "Request Money", value = "Request Money", nickname = "Request",
            tags = {"RequestMoney"} )
    @ApiResponses({
            @ApiResponse(code = 200, message = "Money Requested",response = WalletTransactionHistory.class),
            @ApiResponse(code = 400, message = "Resouce not found" )
    })
    @RequestMapping(value = "/request",method=RequestMethod.POST)
    public ResponseEntity requestMoney(@ApiParam(value = "transaction", required = true ) HumanTransaction htxn,  HttpServletRequest request) throws BadRequestException
    {
        if(null == htxn || htxn.getUsername() == null || htxn.getAmount()==0.0d || htxn.getEmail() == null)
        {
            throw new BadRequestException("request issued is incorrect please correct your input.",URI.create(request.getRequestURI()).getPath());
        }
        try {
            HumanTransaction txn = walletService.requestMoney(htxn);
            return ResponseEntity.accepted().body(txn);
        }
        catch (BadRequestException e)
        {
            logger.severe(e.getMessage());
            e.setPath(URI.create(request.getRequestURI()).getPath());
            throw e ;
        }
    }
    /*
    * method for sending money to an account. the account should be already existing
     */
    @ApiOperation(notes = "Send Money", value = "Send Money", nickname = "Send",
            tags = {"SendMoney"} )
    @ApiResponses({
            @ApiResponse(code = 200, message = "Money Sent",response = WalletTransactionHistory.class),
            @ApiResponse(code = 400, message = "Resouce not found" )
    })
    @RequestMapping(value = "/send",method=RequestMethod.POST)
    public ResponseEntity sendMoney(@ApiParam(value = "transaction", required = true ) HumanTransaction htxn,  HttpServletRequest request) throws BadRequestException
    {
        //TODO validate input
        try {
            HumanTransaction txn = walletService.sendMoney(htxn);
            return ResponseEntity.accepted().body(txn);
        }
        catch (BadRequestException e)
        {
            logger.severe(e.getMessage());
            e.setPath(URI.create(request.getRequestURI()).getPath());
            throw e ;
        }
    }
}


