package info.luxman.pay.model;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public abstract class PaymentMethodImpl {

}
