package info.luxman.pay.pay.service;


import info.luxman.pay.exception.ResourceAlreadyExistsException;
import info.luxman.pay.model.Account;
import info.luxman.pay.model.Wallet;
import info.luxman.pay.service.AccountService;
import info.luxman.pay.service.WalletService;
import info.luxman.pay.util.JwtUtil;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.net.URI;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
@RestController
@RequestMapping("/users")
@Api(basePath = "/users", value = "Account", description = "Operations with an account", produces = "application/json")
public class AccountServiceAPI {

    Logger logger = Logger.getLogger(AccountServiceAPI.class.toString());

    @Value("${jwt.header}")
    private String tokenHeader;

    @Autowired
    private AccountService userService;

    @Autowired
    private WalletService walletService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserDetailsService userDetailsService;
    /*
    * method for logging in the user. Returns success or failure. UI application will use the basic auth creds for subsequent ops
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResponseEntity<info.luxman.pay.model.Authentication> login(@RequestBody info.luxman.pay.model.Authentication authenticationRequest)
    {

        final Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        authenticationRequest.getUsername(),
                        authenticationRequest.getPassword()
                )
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Reload password post-security so we can generate token
        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
      //  final String token = jwtUtil.generateToken(userDetails, device);
        final String token = jwtUtil.createJWTToken(userDetails.getUsername());
        // Return the token
         info.luxman.pay.model.Authentication responseAuth = new info.luxman.pay.model.Authentication();
         responseAuth.setToken(token);
        return ResponseEntity.ok().body(responseAuth);

    }
    @RequestMapping(value = "/refresh", method = RequestMethod.GET)
    public ResponseEntity<?> refreshAndGetAuthenticationToken(HttpServletRequest request) {
        String token = request.getHeader(tokenHeader);
        String username = jwtUtil.getUserNameFromToken(token);
        UserDetails user =  userDetailsService.loadUserByUsername(username);

      //  if (jwtTokenUtil.canTokenBeRefreshed(token, user.getLastPasswordResetDate())) {
        String refreshedToken = jwtUtil.createJWTToken(user.getUsername());
        info.luxman.pay.model.Authentication responseAuth = new info.luxman.pay.model.Authentication();
        responseAuth.setToken(refreshedToken);
        return ResponseEntity.ok(responseAuth);
    }
    @RequestMapping(value = "/logout", method = RequestMethod.POST)
    public ResponseEntity<info.luxman.pay.model.Authentication> logout(@RequestBody info.luxman.pay.model.Authentication authenticationRequest)
    {

        final Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        authenticationRequest.getUsername(),
                        authenticationRequest.getPassword()
                )
        );
        SecurityContextHolder.getContext().getAuthentication().setAuthenticated(false);
        // Reload password post-security so we can generate token
        info.luxman.pay.model.Authentication responseAuth = new info.luxman.pay.model.Authentication();
       // responseAuth.setToken(token);
        return ResponseEntity.ok().body(responseAuth);

    }
    /*
     * this method is for self profile creation. it creates a profile and a wallet entity for the user.
     * Responds with 201 CREATED
     * Failures are responded with corresponding error codes.
     * thrown ones are 409
     */
    @ApiOperation(notes = "creats an account ", value = "create account", nickname = "createAccount",
            tags = {"Accounts"} )
    @ApiResponses({
            @ApiResponse(code = 200, message = "Account created with credit!", response = Account.class),
            @ApiResponse(code = 409, message = "Resouce already exists" )
    })
    @RequestMapping( value="/", method = RequestMethod.POST,consumes = "application/json")
    public ResponseEntity createUser (@ApiParam(value = "account body", required = true) @RequestBody Account account, HttpServletRequest request) throws ResourceAlreadyExistsException {
        logger.info("User to be created " + account.getNickname() );
        try {
            userService.createUser(account);
            Wallet wallet = walletService.createWallet(account);
            Account responseUser = new Account();
            responseUser.setNickname(account.getNickname());
            responseUser.setUsername(account.getUsername());
            responseUser.setId(account.getId());
            return ResponseEntity.created( URI.create(request.getRequestURI()+account.getNickname())).body(responseUser);
        }
        catch (ResourceAlreadyExistsException e)
        {
            logger.severe(e.getMessage());
            e.setPath(URI.create(request.getRequestURI()).getPath());
            throw e ;
        }
    }

    /*
    * this method is for returning a list of registered accounts.
    * TODO
    * implement with username filter.
     */
    @RequestMapping(value="/", method = RequestMethod.GET)
    public List<Account> listAccounts(@RequestParam(name="username",required = false) String username)
    {
        logger.fine(" List accounts ");
        return userService.listAccounts();
    }


}
