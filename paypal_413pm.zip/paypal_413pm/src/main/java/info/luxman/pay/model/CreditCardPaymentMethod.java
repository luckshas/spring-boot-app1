package info.luxman.pay.model;

/**
 * Created by Luxman_S on 4/12/2017.
 */
public class CreditCardPaymentMethod extends PaymentMethodImpl {
    private String creditCardNumber;
    private String creditCardlast4;
    private String expirationDate;
    private Address address;

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getCreditCardlast4() {
        return creditCardlast4;
    }

    public void setCreditCardlast4(String creditCardlast4) {
        this.creditCardlast4 = creditCardlast4;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
