package info.luxman.pay.pay.service;

import info.luxman.pay.exception.BadRequestException;
import info.luxman.pay.exception.ResourceAlreadyExistsException;
import info.luxman.pay.exception.ResourceNotFoundException;
import info.luxman.pay.model.ErrorResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
/*@ControllerAdvice
@RestController
public class GlobalServiceExceptionHandler {
    @ResponseStatus(HttpStatus.CONFLICT)
    @ExceptionHandler(value = ResourceAlreadyExistsException.class)
    public String handleResourceAlreadyExistsExceptionException(ResourceAlreadyExistsException e){
        return e.getMessage();
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = ApplicationException.class)
    public String handleResourceAlreadyExistsExceptionException(ApplicationException e){
        return e.getMessage();
    }

    @ExceptionHandler(value = Exception.class)
    public String handleException(Exception e){return e.getMessage();}
}*/

@ControllerAdvice
public class GlobalServiceExceptionHandler extends ResponseEntityExceptionHandler
{

    @ExceptionHandler({ ResourceAlreadyExistsException.class })
    public ResponseEntity<Object> handleConflict(ResourceAlreadyExistsException ex, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setError(HttpStatus.CONFLICT.getReasonPhrase());
        errorResponse.setStatus(HttpStatus.CONFLICT.value());
        errorResponse.setTimestamp(new Timestamp(new Date().getTime()));
        errorResponse.setMessage(ex.getMessage());
        errorResponse.setPath(ex.getPath());
        return new ResponseEntity<Object>(errorResponse, new HttpHeaders(), HttpStatus.CONFLICT);
    }
    @ExceptionHandler({ BadRequestException.class })
    public ResponseEntity<Object> handleBadRequest(BadRequestException ex, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setError(HttpStatus.BAD_REQUEST.getReasonPhrase());
        errorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
        errorResponse.setTimestamp(new Timestamp(new Date().getTime()));
        errorResponse.setMessage(ex.getMessage());
        errorResponse.setPath(ex.getPath());
        return new ResponseEntity<Object>(errorResponse, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler({ ResourceNotFoundException.class })
    public ResponseEntity<Object> handleNotFoundRequest(BadRequestException ex, WebRequest request) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setError(HttpStatus.NOT_FOUND.getReasonPhrase());
        errorResponse.setStatus(HttpStatus.NOT_FOUND.value());
        errorResponse.setTimestamp(new Timestamp(new Date().getTime()));
        errorResponse.setMessage(ex.getMessage());
        errorResponse.setPath(ex.getPath());
        return new ResponseEntity<Object>(errorResponse, new HttpHeaders(), HttpStatus.NOT_FOUND);
    }
}
