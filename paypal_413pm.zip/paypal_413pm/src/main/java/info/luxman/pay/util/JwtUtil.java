package info.luxman.pay.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Created by Luxman_S on 4/13/2017.
 */
@Service
public class JwtUtil {

    Logger logger = Logger.getLogger(JwtUtil.class.toString());

    @Value("${jwt.secret}")
    public String secret;

    private final static String ISSUER = "paypal";

    private final static String SUBJECT= "AUTH";
    public String createJWTToken(String username)
    {
        //5 minutes
        Date date = new Date(System.currentTimeMillis()+(5*60*1000));

        Map<String,Object> claims = new HashMap<String,Object>();
        claims.put("username",username);

        String token = Jwts.builder()
                .setClaims(claims)
                .setExpiration(date)
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();

        return token;
    }

    public boolean validateToken(String jwtToken, String inputUsername)
    {
        String username = this.getUserNameFromToken(jwtToken);
        logger.info("token username:"+username+" passed User "+ inputUsername);

        if(null == username )
        {
            return false;
        }
        if(username.equals(inputUsername))
        {
            return true;
        }
        return false;

    }
    public String getUserNameFromToken(String jwtToken)
    {
        Claims claims;
        try {
            claims = Jwts.parser()
                    .setSigningKey(secret)
                    .parseClaimsJws(jwtToken)
                    .getBody();

            return (String) claims.get("username");
        } catch (Exception e) {
            e.printStackTrace();
            claims = null;
        }

        return null;

    }
}
