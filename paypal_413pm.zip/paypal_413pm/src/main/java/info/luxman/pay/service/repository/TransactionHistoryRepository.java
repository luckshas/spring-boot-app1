package info.luxman.pay.service.repository;

import info.luxman.pay.model.WalletTransactionHistory;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * Created by luxmanseshadri on 4/12/17.
 */
public interface TransactionHistoryRepository  extends MongoRepository<WalletTransactionHistory,String> {
    List<WalletTransactionHistory> getActivityById(String id);
}
