package info.luxman.pay.service;

import info.luxman.pay.model.Account;
import info.luxman.pay.model.Wallet;
import info.luxman.pay.model.WalletTransactionHistory;
import info.luxman.pay.service.repository.WalletRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;

/**
 * Created by luxmanseshadri on 4/13/17.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@SpyBean(WalletService.class)
public class WalletServiceTest {
    @Autowired
    WalletService walletService;

    @Autowired
    WalletRepository walletRepo;
    @Test
    public void createWallet() throws Exception {
        Account newAccount = new Account();
        newAccount.setUsername("sample@s.com");
        newAccount.setPassword("pwd");
        newAccount.setNickname("sample");
        WalletTransactionHistory txh = new WalletTransactionHistory();
        txh.setUsername(newAccount.getUsername());
        Wallet wallet = new Wallet();
        wallet.setBalance(100);
        wallet.setUsername(newAccount.getUsername());
        //given(this.walletService.addTransactionHistory(wallet,eq(""))).willReturn(txh);


        //given(this.walletRepo.save(any(Wallet.class))).willReturn(wallet);

        Wallet rcvdWallet =  walletService.createWallet(newAccount);
        assertEquals(rcvdWallet.getBalance()+"",wallet.getBalance()+"");
        assertEquals(rcvdWallet.getUsername(),wallet.getUsername());
    }

    @Test
    public void addTransactionHistory() throws Exception {
    }

    @Test
    public void getTransactionHistory() throws Exception {
    }

    @Test
    public void getWalletByEmail() throws Exception {
    }

    @Test
    public void getWalletHistoryByEmail() throws Exception {
    }

    @Test
    public void requestMoney() throws Exception {
    }

    @Test
    public void sendMoney() throws Exception {
    }

    @Test
    public void findHumanTransactionNotCompletedForAUser() throws Exception {
    }

}