package info.luxman.pay.service;

import info.luxman.pay.exception.ResourceAlreadyExistsException;
import info.luxman.pay.model.Account;
import info.luxman.pay.service.repository.AccountRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;


import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;

/**
 * Created by luxmanseshadri on 4/13/17.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class AccountServiceTest {
    @MockBean
    private AccountRepository userRepository;

    @Autowired
    private AccountService accountService;

    @MockBean
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Test
    public void createUserAlreadyExists()  {
        Account existingUser = new Account();
        existingUser.setUsername("sample@s.com");
        existingUser.setPassword("pwd");
        existingUser.setNickname("sample");
        given(this.userRepository.findUserByUsername(anyString())).willReturn(existingUser);
        given(this.bCryptPasswordEncoder.encode(anyString())).willReturn("asdasdasdasd");

        Account newAccount = new Account();
        newAccount.setUsername("sample@s.com");

        try {
            accountService.createUser(newAccount);
        } catch (ResourceAlreadyExistsException e) {
           assertEquals(e.getMessage(),"Account already exists"+newAccount.getUsername());
        }
    }
    @Test
    public void createUser()  {
        Account newAccount = new Account();
        newAccount.setUsername("sample@s.com");
        newAccount.setPassword("pwd");
        newAccount.setNickname("sample");
        given(this.userRepository.findUserByUsername(anyString())).willReturn(null);
        given(this.bCryptPasswordEncoder.encode(anyString())).willReturn("asdasdasdasd");
        given(this.userRepository.save(any(Account.class))).willReturn(newAccount);

        Account expectedAccount = null;
        try {
            expectedAccount = accountService.createUser(newAccount);
        } catch (ResourceAlreadyExistsException e) {
            fail(e.getMessage());
        }
        ((CrudRepository)verify(userRepository,atLeast(1))).save(any(Account.class));


    }

    @Test
    public void listAccounts() throws Exception {

        given(userRepository.findAll()).willReturn(null);
        List<Account> accounts = accountService.listAccounts();
        assertEquals(accounts,null);
    }

}