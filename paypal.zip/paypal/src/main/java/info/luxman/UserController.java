package info.luxman;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by luxmanseshadri on 4/11/17.
 */
@RestController
public class UserController {
    @RequestMapping("/login2")
    public String login()
    {
        return "login1";
    }
    @RequestMapping("/login-error")
    public String loginError()
    {
        return "login-error";
    }
    @RequestMapping("/resource")
    public Map<String,Object> home() {
        Map<String,Object> model = new HashMap<String,Object>();
        model.put("id", UUID.randomUUID().toString());
        model.put("content", "Hello World");
        return model;
    }

}
