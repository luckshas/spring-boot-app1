package info.luxman;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

/**
 * Created by luxmanseshadri on 4/11/17.
 */
@RestController
@RequestMapping("/service")
public class UserServiceAPI {

    @RequestMapping(value = "/login1", method = RequestMethod.POST)
    public String login(User princ)
    {
        return "{\"authenticated\":true} ";
    }
}
