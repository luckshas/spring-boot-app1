var app = angular.module('login', ['ngRoute','ngMaterial']);
//,"ngSanitize","ui.bootstrap"

app.config(function ($routeProvider) {
    $routeProvider
    // login view definition
        .when("/login", {
            controller: "loginController",
            controllerAs: "vm",
            templateUrl: "login.html"
        })
        .when("/account",{
            controller: "mainController",
            contollerAs:"vm",
            templateUrl:"account.html"
        }).
        when("/register",{
        controller: "registerController",
        contollerAs:"vm",
        templateUrl:"register.html"
    })
        // many other routes could be defined here
        // and redirect the user to the main view if no routes match
        .otherwise({
            redirectTo: "/login"
        });
});
app.service("loginService", function ($http) {
    return {
        login: function (user, pass) {
            return $http.post("service/login1", {
                    username: user,
                    password: pass
                }
            ).then(function (response) {
                return response.data;
            }, function (response) {
                var err = new Error(response.statusText);
                err.code = response.status;
                throw err;
            });
        }
    };
});
app.controller("loginController", function ($rootScope, $scope, $location,loginService) {
    var vm = this;
   // loginService.checkLogin().then(success);
    $scope.alerts = [
        { type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.' },
    ];
    function init()
    {
      //  $rootScope.loggedIn=false;
    }
    function success() {
        $rootScope.loggedIn = true;
        var back = $location.search().back || "";
        $location.url(back !== "/login" ? back : "");
        }

    function failure() {
        $rootScope.loggedIn = false;
        $rootScope.message=$scope.alerts[1];
    }

    vm.login = function () {
        loginService.login(vm.user, vm.pass).then(success, failure);
    };
});

app.controller("mainController",function($rootScope,$scope)
{
    $scope.currentNavItem = 'page1';

});
app.controller("registerCounter",function($rootScope,$scope)
{

});
app.run(function ($rootScope, $location) {
    // attach to the event that fires before the router changes routes
    $rootScope.$on("$routeChangeStart", function (event, next) {
        // check current login status and filter out if navigating to login
        if (!$rootScope.loggedIn && next.originalPath !== "/login") {
            // remember the original url
            $location.url("/login?back=" + $location.url());
        }
    });
});